from VDF import *
from utils import *

assert comp(27, 2, 3) == (2 ** (2**3)) % 27

