from VDF import *
from parallel_scheme import *

T = 2 ** 11
N = setup(64)
x = gen(N)
"""
for i in range(100):
    x = gen(N)
    assert assert_mem(x, N)
    y = gen(N)
    assert assert_mem(y, N)
    tmp = abs ((x * y) % N)
    assert assert_mem(tmp, N)
"""
print("Solving...")
y = comp(N, x, T)
print ("basic y=", y)
print("... (simple) Solving done")
print("Proving...")
pi = prov(N, x, T, y)
print("basic pi=", pi)
print("...(simple) Proving done")
print("Verifying...")
verify(N, x, T, y, pi)

def vf(pp, y_p, y, S_i, pi_i) :
    return verify(N, y_p, S_i, y, pi_i) 

def evaluate(N, x, T):
    res = comp(N, x, T)
    return res, prov(N, x, T, res)

parallel = Parallel_scheme( T, setup, gen, evaluate, vf, prov, comp)

y_parallel, pi_parallel = parallel.eval_(N, x, T)
print ("parallel y=", y_parallel)
print("parallel pi=", pi_parallel)
print(parallel.vf_(N, x, y_parallel, pi_parallel, T))

